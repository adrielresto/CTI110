Python 3.11.1 (tags/v3.11.1:a7a450f, Dec  6 2022, 19:58:39) [MSC v.1934 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
========== RESTART: C:/Users/restoa1637/Downloads/P1HW2_RestoAdriel.py =========
This program calculates and displays travel expenses

Enter budget:5450

Enter your travel destination:Japan

How much do you think you will spend on gas?:100

Approximately, how much will you need for accomodation/hotel?:304

Last, how much do you need for food?:200

------------ Travel Expenses ------------
Location: Japan
Inital Budegt: 5450.0

Fuel: 100.0
Accomodation: 304.0

Remaining Balance: 4,846
