# This program calculates and displays expenses
# 02/28/23
# CTI-110 P2HW1 - Travel expenses(Japan)
# Adriel Resto

print("This program calculates and displays travel expenses:")
print()
budget = input("Enter budget:")
print()
name = input("Enter travel destination:")
print()
gas = input ("How much do you think you will spend on gas?:")
print()
hotel = input("Approximately, how much will you need for accomodation/hotel?:")
print()
food = input("Last, how much do you need for food?:")
print()
print("-"*12,"Travel Expenses",12*'-')
print("Location:           ",'Japan')
print("Budget:            $",'5,450')

print("gas:               $",'100')
print("hotel              $",'304')
print("food:              $",'200')

print('-'*44)

# print("Remaining balance: ", balance)
print("Remaining Balance: $",'4,846')
             
                  
               
