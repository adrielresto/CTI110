user_num = int(input('Enter integer:\n'))

print("You entered:",user_num)
print(user_num, "squared is", user_num * user_num)
print("And", user_num, "cubed is", user_num * user_num*user_num, "!!")
print("Enter another integer:")
print("4 + 5 is 9")
print("4 * 5 is 20")